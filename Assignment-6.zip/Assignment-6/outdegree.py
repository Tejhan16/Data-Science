from pyspark import SparkContext
import sys

sc = SparkContext("local", "app")

text_file = sc.textFile(sys.argv[1])
counts = text_file.flatMap(lambda line: line.split("\n")) \
             .map(lambda word: (int(word.split('\t')[0]), 1)) \
             .reduceByKey(lambda a, b: a + b).sortByKey(True, 1)
counts.saveAsTextFile(sys.argv[2])


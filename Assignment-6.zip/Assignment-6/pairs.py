from pyspark import SparkContext
import sys

sc = SparkContext("local", "app")

text_file = sc.textFile(sys.argv[1])
rdd1 = text_file.flatMap(lambda line: line.split("\n")) \
             .map(lambda word: (word.split('\t')[0], word.split('\t')[1]))
rdd2 = text_file.flatMap(lambda line: line.split('\n')).map(lambda word: (word.split('\t')[1], word.split('\t')[0]))

rdd1.join(rdd2, ).reduceByKey(lambda a,b: a+b)
rdd1.saveAsTextFile(sys.argv[2])

from pyspark import SparkContext
import sys

sc = SparkContext("local", "app")

text_file = sc.textFile(sys.argv[1])
weight = text_file.flatMap(lambda line: line.split("\n")) \
             .map(lambda word: (int(word.split('\t')[0]), int(word.split('\t')[2]))) \
             .reduceByKey(lambda a, b: a + b).sortByKey(True, 1)
weight.saveAsTextFile(sys.argv[2])

